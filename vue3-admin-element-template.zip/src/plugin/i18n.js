import i18n from '@/locales';
export default function loadComponent(app) {
  app.use(i18n);
}

export const noticeList = [
  {
    id: 1,
    title: '您收到了新的周报消息',
    time: '2021-8-27 12:30:23',
    icon: 'mail',
  },
  {
    id: 2,
    title: 'vue3-admin已更新到最新版本',
    time: '2021-8-28 15:20:53',
    icon: 'mail',
  },
  {
    id: 3,
    title: '最新功能通知',
    time: '2021-8-29 15:20:53',
    icon: 'mail',
  },
  {
    id: 4,
    title: '收到了一条gitstart新增消息',
    time: '2021-8-23 15:20:53',
    icon: 'github',
  },
  {
    id: 5,
    title: '系统数据更新1000+条',
    time: '2021-8-21 15:20:53',
    icon: 'mail',
  },
];
